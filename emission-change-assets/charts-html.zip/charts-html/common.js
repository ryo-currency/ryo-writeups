Chart.defaults.global.defaultFontColor = "#888888";
Chart.defaults.global.defaultFontSize = 16;
Chart.defaults.global.defaultFontFamily = "Saira";
Chart.defaults.scale.gridLines.color = "#DDD"
