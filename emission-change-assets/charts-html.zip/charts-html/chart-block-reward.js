new Chart(document.getElementById('canvas_1').getContext('2d'), {
  type: 'line',
  data: {
    labels: block_reward.labels,
    datasets: [{
      label: 'Ryo (current)',
      borderColor: "#1f77b4",
      backgroundColor: "#1f77b4",
      fill: false,
      steppedLine: "after",
      data: block_reward.data[0]
    }, {
      label: 'Ryo (proposed)',
      borderColor: "#2ca02c",
      backgroundColor: "#2ca02c",
      fill: false,
      steppedLine: "after",
      data: block_reward.data[1]
    }, {
      label: 'Ryo (plateau 12)',
      borderColor: "#b7950b",
      backgroundColor: "#b7950b",
      fill: false,
      steppedLine: "after",
      data: block_reward.data[2]
    }, {
      label: 'Ryo (plateau 18)',
      borderColor: "#a700c0",
      backgroundColor: "#a700c0",
      fill: false,
      steppedLine: "after",
      data: block_reward.data[3]
    }]
  },
  options: {
    responsive: true,

    legend: {
      position: 'top',
    },
    title: {
      display: true,
      text: 'Block Reward by Year'
    },
    elements: {
      point: { radius: 0 },
       line: {
        borderWidth: 1.5,
            tension: 0
        }
    },
    scales: {
      xAxes: [{
        type: 'time',
      }],
    }
    
  }
});
