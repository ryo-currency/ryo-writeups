new Chart(document.getElementById('canvas_5').getContext('2d'), {
  type: 'line',
  data: {
    labels: block_reward_compare.labels,
    datasets: [{
      label: 'Ryo (current)',
      borderColor: "#1f77b4",
      backgroundColor: "#1f77b4",
      fill: false,
      steppedLine: "after",
      data: block_reward_compare.data[0]
    }, {
      label: 'Ryo (proposed)',
      borderColor: "#2ca02c",
      backgroundColor: "#2ca02c",
      fill: false,
      steppedLine: "after",
      data: block_reward_compare.data[1]
    }, {
      label: 'Ryo (plateau 12)',
      borderColor: "#b7950b",
      backgroundColor: "#b7950b",
      steppedLine: "after",
      fill: false,
      data: block_reward_compare.data[2]
    }, {
      label: 'Ryo (plateau 18)',
      steppedLine: "after",
      borderColor: "#a700c0",
      backgroundColor: "#a700c0",
      fill: false,
      data: block_reward_compare.data[3]
    }, {
      label: 'Monero',
      borderColor: "#ff7f0e",
      backgroundColor: "#ff7f0e",
      fill: false,
      data: block_reward_compare.data[4]
    }, {
      label: 'Bitcoin',
      steppedLine: "after",
      borderColor: "#d62728",
      backgroundColor: "#d62728",
      fill: false,
      data: block_reward_compare.data[5]
    }]
  },
  options: {
    responsive: true,

    legend: {
      position: 'top',
    },
    title: {
      display: true,
      text: 'Block Reward by Year'
    },
    scales: {
      yAxes: [{
        ticks: {
          callback: function(value, index, values) {
            return value+"";
          }
        }
      }],
      xAxes: [{
        ticks: {
          userCallback: function(item, index) {
            if (!(index % 12)) {
              return ((item/12)+1);
            }
          },
          minRotation: 0,
          maxRotation: 0,
          autoSkip: false
        },
        scaleLabel: {
          display: true,
          labelString: 'Year Number'
        }
      }]
    },
    elements: {
      point: {
        radius: 0
      },
      line: {
        borderWidth: 1.5,
        tension: 0
      }
    },
    
  }
});
